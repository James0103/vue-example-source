<template lang="pug">
  div(id="app")
    div(class="section description")
      div(class="contents title") {{ TITLE }}
      div(class="contents desc", v-html="DESC")
      div(class="contents caution", v-html="CAUTION")
    div(class="section example")
      example1(v-for="(item, index) in COLORDATA", :key="index", :color="item")
</template>

<style lang="scss">
html, body {
  width: 100%;
  height: 100%;
  margin: 0;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  height: 100%;
  box-sizing: border-box;
  padding: 2rem;
  display: flex;
  flex-direction: column;
}

#app>.section.description {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex-basis: 30%;
  .contents {
    text-align: left;
    margin-bottom: 0.5rem;
  }
  .contents.title {
    font: {
      size: 2rem;
      weight: 600;
    }
  }
}

#app>.section.example {
  display: flex;
  flex-direction: row;
  flex-basis: 70%;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
}
</style>

<script>
import example1 from './components/example1.vue';

export default {
  name: 'App',
  components: { example1 },
  data: () => ({
    TITLE: 'vue.js 와 HTML의 기초적인 내용을 통해 아래 예제를 만들어보자',
    DESC: '아는 모든 지식을 동원해서 아래 예제를 만들어봅시다.<br>단 몇가지 주의사항이 있습니다',
    CAUTION: '1. 프로젝트 생성시 babel과 scss만 적용하고 나머지는 적용하지 않습니다.<br>2. HTML 안에 직접적으로 텍스트를 입력하지 않습니다.<br>ex) div(class="title") vue.js 와 HTML의 기초적인 내용을 통해 아래 예제를 만들어보자 <- 이런식으로 입력하지 않습니다<br>3. 컴포넌트를 사용해서 아래 박스를 만들고, 복제해서 사용합니다.',
    COLORDATA: [
      { bg: 'rgb(51,51,51)', text: 'rgb(200,200,200)' },
      { bg: 'rgb(148,240,238)', text: 'rgb(97,150,123)' },
      { bg: 'rgb(97,150,238)', text: 'rgb(110,80,230)' },
    ],
  }),
};
</script>
