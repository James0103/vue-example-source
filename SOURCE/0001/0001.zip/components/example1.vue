<template lang="pug">
  div(class="example-1", :style="{'background-color': color.bg}")
    div(class="section")
      div(class="contents title", :style="{'color': color.text }", v-html="TITLE")
      input(v-model="EX1DATA", type="textarea", class="contents inputbox")
      div(class="contents answer", :style="{'color': color.text}") {{ EX1DATA }}
</template>

<style lang="scss" scoped>
.example-1 {
  width: 30%;
  min-width: 300px;
  max-width: 400px;
  height: 35%;
  border-radius: 1rem;
  padding: 1rem;
  box-sizing: border-box;
  margin: 0.5rem;
}
.example-1>.section {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.example-1>.section>.contents {
  margin-bottom: 1rem;
  &.title {
    font-weight: 600;
    font-size: 1rem;
  }
  &.inputbox {
    width: 100%;
  }
}
</style>

<script>
export default {
  name: 'example-1',
  props: { color: Object },
  data: () => ({
    TITLE: '인풋 박스에 키워드를 입력하면<br>바로 아래 그대로 출력이 됩니다.',
    EX1DATA: '',
  }),
};
</script>
