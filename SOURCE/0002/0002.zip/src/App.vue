<template lang="pug">
  div(id="app")
    div(class="section description")
      div(class="contents title") {{ TITLE }}
      div(class="contents desc", v-html="DESC")
      //- div(class="content caution", v-html="CAUTION")
    div(class="section example")
      example2
</template>

<style lang="scss">
html, body {
  width: 100%;
  height: 100%;
  margin: 0;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  height: 100%;
  box-sizing: border-box;
  padding: 2rem;
  display: flex;
  flex-direction: column;
}

#app>.section.description {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex-basis: 30%;
  .contents {
    text-align: left;
    margin-bottom: 0.5rem;
  }
  .contents.title {
    font: {
      size: 2rem;
      weight: 600;
    }
  }
}

#app>.section.example {
  display: flex;
  flex-direction: row;
  flex-basis: 70%;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
}
</style>

<script>
import example2 from './components/example2.vue';

export default {
  name: 'App',
  components: { example2 },
  data: () => ({
    TITLE: 'vue.js 의 computed, watch 속성을 사용해보자',
    DESC: 'computed, watch 속성에 대해 같이 배워보고, 적용해봅시다',
  }),
};
</script>
