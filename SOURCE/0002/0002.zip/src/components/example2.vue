<template lang="pug">
  div(class="example-2")
    div(class="method first")
      div(class="title") {{ TITLES[0] }}
      div(class="function-area")
        input(type="textarea", v-model="methodFirst", @input="resetMethodsFirst")
        button(class="submit btn", @click="setMethodsFirst") {{ METHODS[0] }}
      div(v-if="showFirst", class="result first") {{ firstResult }}
    div(class="method second")
      div(class="title") {{ TITLES[1] }}
      div(class="function-area")
        input(type="textarea", v-model="methodSecond")
        //- button(class="submit btn") {{ METHODS[1] }}
      div(class="result second") {{ secondResult }}
</template>

<style lang="scss" scoped>
.example-2 {
  width: 100%;
  height: 100%;
  border-radius: 1rem;
  padding: 1rem;
  box-sizing: border-box;
  margin: 0.5rem;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
}
.example-2>.method {
  flex-basis: 50%;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
</style>

<script>
export default {
  name: 'example-2',
  data: () => ({
    TITLES: ['글자 뒤에 다른 말을 붙여서 출력해보자', '좋아하는 과일을 적어보세요(영어로)'],
    METHODS: ['첫번째 함수 실행', '두번째 함수 실행'],
    methodFirst: '',
    showFirst: false,
    methodSecond: '',
    secondResult: '입력을 기다리고 있습니다',
  }),
  computed: {
    firstResult() {
      return `${this.methodFirst} <- 입력한 내용`;
    },
  },
  watch: {
    methodSecond() {
      if (this.methodSecond.length !== 0) {
        if (this.methodSecond === 'apple') {
          this.secondResult = '사과를 좋아하나요?';
        } else if (this.methodSecond === 'banana') {
          this.secondResult = '바나나를 좋아하나요?';
        } else {
          this.secondResult = '입력중';
        }
      } else {
        this.secondResult = '입력을 기다리고 있습니다';
      }
    },
  },
  methods: {
    setMethodsFirst() {
      this.showFirst = true;
    },
    resetMethodsFirst() {
      this.showFirst = false;
    },
  },
};
</script>
