<template lang="pug">
  div(class="customize-element")
    div(class="section button")
      div(class="contents title") 버튼
      div(class="contents elements")
        button(class="btn ori") ORIGINAL
        button(class="btn cus") CUSTOM BUTTON
    div(class="section slider")
      div(class="contents title") 슬라이더
      div(class="contents elements")
        input(type="range", class="slider ori")
        input(type="range", class="slider cus", :style="{'--slider-value': customSliderValue }", @input="getCustomSliderValue")
    div(class="section radio")
      div(class="contents title") 라디오 버튼
      div(class="contents elements")
        form(class="radio ori")
          input(type="radio", id="ori-1", name="ori", value="1")
          label(for="ori-1") 1
          input(type="radio", id="ori-2", name="ori", value="2")
          label(for="ori-2") 2
          input(type="radio", id="ori-3", name="ori", value="3")
          label(for="ori-3") 3
        form(class="radio cus")
          div(class="elem")
            input(type="radio", id="cus-1", name="cus", value="1")
            span(class="checkmark")
            label(for="cus-1") 1
          div(class="elem")
            input(type="radio", id="cus-2", name="cus", value="2")
            span(class="checkmark")
            label(for="cus-2") 2
          div(class="elem")
            input(type="radio", id="cus-3", name="cus", value="3")
            span(class="checkmark")
            label(for="cus-3") 3
</template>

<style lang="scss" scoped>
.customize-element {
  width: 100%;
  height: 100%;
  border-radius: 1rem;
  padding: 1rem;
  box-sizing: border-box;
  margin: 0.5rem;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}
.customize-element>.section {
  width: 100%;
  height: 10%;
  display: flex;
  flex-direction: row;
}
.customize-element>.section>.contents {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  &.title {
    flex-basis: 20%;
  }
  &.elements {
    flex-basis: 80%;
    display: flex;
    flex-direction: row;
    justify-content: center;
  }
}
.customize-element>.section>.contents>.btn {
  width: 200px;
  height: 50%;
  margin: 0 1rem;
  &.cus {
    font: {
      weight: 600;
      size: 0.75rem;
    }
    border: {
      style: none;
      radius: 0.5rem;
    }
    background-color: rgb(37,131,255);
    color: white;
    outline: none;
    cursor: pointer;
    transition: transform 0.1s ease-in-out, background-color 0.25s ease-in-out;
    &:active {
      transform: scale(0.9);
      -webkit-transform: scale(0.9);
    }
    &:hover {
      background-color: darken(rgb(37,141,255), 25%);
    }
  }
}
.customize-element>.section>.contents>.slider {
  $slider-thumb-size: 1.5rem;
  $slider-track-height: 0.75rem;
  width: 200px;
  height: 50%;
  margin: 0 1rem;
  &.cus {
    -webkit-appearance: none;
    outline: none;
    background-color: transparent;
    border: 0;
  }
  &.cus:focus {
    outline: none;
  }
  &.cus::-webkit-slider-thumb {
    -webkit-appearance: none;
    border-radius: 0.5rem;
    cursor: pointer;
    background: rgb(255,28,149);
    width: $slider-thumb-size;
    height: $slider-thumb-size;
    margin-top: -(($slider-thumb-size * 0.5) - ($slider-track-height * 0.5));
  }
  &.cus::-webkit-slider-runnable-track {
    -webkit-appearance: none;
    width: 100%;
    height: $slider-track-height;
    border-radius: 0.5rem;
    cursor: pointer;
    border: 0px solid #000101;
    padding: 0 0.001rem;
    background-image: -webkit-gradient(linear, left top, right top, color-stop(var(--slider-value), rgb(255,28,149)), color-stop(var(--slider-value), #a8a8a8));
  }
}
.customize-element>.section>.contents>.radio {
  width: 200px;
  height: 50%;
  margin: 0 1rem;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  &.cus>.elem {
    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items: center;
    input[type=radio] {
      position: absolute;
      opacity: 0;
      height: 0;
      width: 1.5rem;
      height: 1.5rem;
      cursor: pointer;
    }
    .checkmark {
      width: 1.5rem;
      height: 1.5rem;
      background-color: #eee;
      cursor: pointer;
      border-radius: 1rem;
      margin: 0 0.5rem 0 1rem;
    }
    input[type=radio]:checked ~ .checkmark {
      background-color: rgb(255,183,28)
    }
    .checkmark:after {
      content: "";
      display: none;
    }
    input[type=radio]:checked ~ .checkmark:after {
      display: block;
    }
    .checkmark:after {
      border: solid white;
      border-width: 0.4rem;
      border-radius: 50%;
      width: 0rem;
      height: 0rem;
      $margin-value: ((1.5rem / 2) - 0.4rem);
      margin: $margin-value 0 0 $margin-value;
    }
  }
}
</style>

<script>
export default {
  name: 'customize-element',
  data: () => ({
    customSliderValue: '50%'
  }),
  methods: {
    getCustomSliderValue: function (event) {
      this.customSliderValue = `${event.target.value}%`
    }
  }
}
</script>
