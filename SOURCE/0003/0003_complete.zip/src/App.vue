<template lang="pug">
  div(id="app")
    div(class="section description")
      div(class="contents title") {{ TITLE }}
      div(class="contents desc", v-html="DESC")
      div(class="contents caution", v-html="CAUTION")
    div(class="section example")
      customizeElem
</template>

<style lang="scss">
html, body {
  width: 100%;
  height: 100%;
  margin: 0;
}
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  height: 100%;
  box-sizing: border-box;
  padding: 2rem;
  display: flex;
  flex-direction: column;
}

#app>.section.description {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  flex-basis: 10%;
  .contents {
    text-align: left;
    margin-bottom: 0.5rem;
  }
  .contents.title {
    font: {
      size: 2rem;
      weight: 600;
    }
  }
}

#app>.section.example {
  display: flex;
  flex-direction: row;
  flex-basis: 90%;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: center;
}
</style>

<script>
import customizeElem from './components/customizeElem'
export default {
  name: 'App',
  components: { customizeElem },
  data: () => ({
    TITLE: 'CSS로 Element를 커스터마이징해보자',
    DESC: 'CSS로 기본 Element인 버튼, 슬라이더, 라디오 버튼, 토글을 커스터마이징 해봅시다',
    CAUTION: ''
  })
}
</script>
